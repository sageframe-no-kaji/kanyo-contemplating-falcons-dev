"""
Generation module - Static site generation from detection data.
"""

__all__ = ["site_generator"]
