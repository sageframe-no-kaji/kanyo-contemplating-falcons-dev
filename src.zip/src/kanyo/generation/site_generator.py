"""Static site generator for kanyo outputs."""
